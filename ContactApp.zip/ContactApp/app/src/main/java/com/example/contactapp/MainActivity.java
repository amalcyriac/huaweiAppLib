package com.example.contactapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper myDb;
    EditText textName, textNumber, textImgName, textEmail;
    Button btnAdd, btnView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //this.deleteDatabase("myDb");
        myDb = new DatabaseHelper(this);
        //myDb.onUpgrade("contact.db", 1 ,2);
        textName = (EditText)findViewById(R.id.textName);
        textNumber = (EditText)findViewById(R.id.textNumber);
        textImgName = (EditText)findViewById(R.id.textImgName);
        textEmail = (EditText)findViewById(R.id.textEmail);
        btnAdd = (Button)findViewById(R.id.btnAdd);
        btnView = (Button)findViewById(R.id.btnView);
        AddData();
        ViewData();
    }

    public void AddData() {
        btnAdd.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDb.insertData(textName.getText().toString(),
                                textNumber.getText().toString(),
                                textImgName.getText().toString(),
                                textEmail.getText().toString() );
                        if(isInserted) Toast.makeText(MainActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
                        else Toast.makeText(MainActivity.this, "Data not Inserted", Toast.LENGTH_LONG).show();

                    }
                }
        );
    }

    public void ViewData() {
        btnView.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(MainActivity.this, ListDataActivity.class);
                        startActivity(intent);
                    }
                }
        );
    }

    private void toastMessage(String message) {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }

}