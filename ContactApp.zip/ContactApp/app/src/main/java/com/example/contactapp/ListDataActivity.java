package com.example.contactapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListDataActivity extends AppCompatActivity {

    DatabaseHelper myDb;
    ListView myListView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_layout);
        myListView = (ListView)findViewById(R.id.listView);
        myDb = new DatabaseHelper(this);
        populateListView();
    }

    private void populateListView() {
        Cursor data = myDb.getData();
        ArrayList<Person> listData = new ArrayList<>();
        while(data.moveToNext()) {
            String name = data.getString(1);
            int imageNumber = Integer.parseInt(data.getString(3));
            int imageResource = getImageResource(imageNumber);
            Person person = new Person(name, imageResource);
            listData.add(person);
        }

        PersonAdapter personAdapter = new PersonAdapter(this,R.layout.list_row,listData);
        myListView.setAdapter(personAdapter);

        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                data.moveToPosition(position);
                String clickedId = data.getString(0);
                Intent intent = new Intent(ListDataActivity.this, ContactDetailsActivity.class);
                intent.putExtra("clickedId",clickedId);
                startActivity(intent);
            }
        });
    }

    private int getImageResource(int num) {
        if(num == 1) return R.drawable.alicia2;
        else if (num == 2) return R.drawable.hust;
        else if (num == 3) return R.drawable.jack;
        else if (num == 4) return R.drawable.jurica;
        else return R.drawable.ic_launcher_background;
    }

    private void toastMessage(String message) {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
}
