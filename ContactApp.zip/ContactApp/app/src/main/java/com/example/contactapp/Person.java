package com.example.contactapp;

public class Person {
    private String name;
    private int image;

    public Person(String name, int image) {
        this.name = name;
        this.image = image;
    }
    public String getName() { return name; }
    public int getImage() { return image; }
}

