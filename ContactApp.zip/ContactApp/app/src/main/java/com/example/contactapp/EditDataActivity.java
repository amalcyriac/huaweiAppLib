package com.example.contactapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class EditDataActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_data);
        Intent intent = getIntent();
        String clickedId = intent.getStringExtra("clickedId");
        ImageView imgProfile = (ImageView)findViewById(R.id.imgProfileEdit);
        EditText nameView = (EditText) findViewById(R.id.editDataTextName);
        EditText numberView = (EditText)findViewById(R.id.editDataTextNumber);
        EditText emailView = (EditText)findViewById(R.id.editDataTextEmail);
        EditText imgView = (EditText)findViewById(R.id.editDataTextImg);
        Button saveBtn = (Button)findViewById(R.id.editDataSaveBtn);

        DatabaseHelper myDb;
        myDb = new DatabaseHelper(this);
        Cursor data = myDb.getRow(Integer.parseInt(clickedId));
        data.moveToFirst();
        String name = data.getString(1);
        String number = data.getString(2);
        String image = data.getString(3);
        String email = data.getString(4);
        nameView.setText(name);
        numberView.setText(number);
        emailView.setText(email);
        imgView.setText(image);

        int imageResource = getImageResource(Integer.parseInt(image));
        //int imageResource = getResources().getIdentifier("@drawable/hust", null, this.getPackageName());
        imgProfile.setImageResource(imageResource);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String newName = nameView.getText().toString();
                String newNumber = numberView.getText().toString();
                String newEmail = emailView.getText().toString();
                String newImg = imgView.getText().toString();
                myDb.updateData(Integer.parseInt(clickedId),newName,newNumber,newEmail,newImg);

                Intent intent = new Intent(EditDataActivity.this, ContactDetailsActivity.class);
                intent.putExtra("clickedId", clickedId);
                startActivity(intent);
            }
        });
    }

    private int getImageResource(int num) {
        if(num == 1) return R.drawable.alicia2;
        else if (num == 2) return R.drawable.hust;
        else if (num == 3) return R.drawable.jack;
        else if (num == 4) return R.drawable.jurica;
        else return R.drawable.ic_launcher_background;
    }

    private void toastMessage(String message) {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
}