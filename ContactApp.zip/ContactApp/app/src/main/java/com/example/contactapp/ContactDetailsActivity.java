package com.example.contactapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ContactDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_details);
        Intent intent = getIntent();
        String clickedId = intent.getStringExtra("clickedId");
        ImageView imgProfile = (ImageView)findViewById(R.id.imgProfile);
        TextView nameView = (TextView)findViewById(R.id.contactDetailsName);
        TextView numberView = (TextView)findViewById(R.id.contactDetailsNumber);
        TextView emailView = (TextView)findViewById(R.id.contactDetailsEmail);
        Button editBtn = (Button)findViewById(R.id.contactDetailsEditBtn);

        DatabaseHelper myDb;
        myDb = new DatabaseHelper(this);
        Cursor data = myDb.getRow(Integer.parseInt(clickedId));
        data.moveToFirst();
        String name = data.getString(1);
        String number = data.getString(2);
        String image = data.getString(3);
        String email = data.getString(4);
        nameView.setText("Name : " + name);
        numberView.setText("Number : " + number);
        emailView.setText("Email : " + email);

        int imageResource = getImageResource(Integer.parseInt(image));
        //int imageResource = getResources().getIdentifier("@drawable/hust", null, this.getPackageName());
        imgProfile.setImageResource(imageResource);

        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ContactDetailsActivity.this, EditDataActivity.class);
                intent.putExtra("clickedId", clickedId);
                startActivity(intent);
            }
        });
    }

    private int getImageResource(int num) {
        if(num == 1) return R.drawable.alicia2;
        else if (num == 2) return R.drawable.hust;
        else if (num == 3) return R.drawable.jack;
        else if (num == 4) return R.drawable.jurica;
        else return R.drawable.ic_launcher_background;
    }

    private void toastMessage(String message) {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
}